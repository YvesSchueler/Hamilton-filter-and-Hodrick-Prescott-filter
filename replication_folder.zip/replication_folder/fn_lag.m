function [Y Ylag] = fn_lag(Ydata,p,c)
%last updated: October, 26 2011
%Fabian Fink and Yves S. Schueler (University of Konstanz)
%
%function description: 
%this function manipulates the data matrix.
%
%input:
% Ydata is a T x M data matrix
% p is the number of lags used in VAR
% c=1 constant, c=0 no constant
%output:
% Y
% Ylag

[T_raw M] = size(Ydata);
%initialize Ylag
Ylag = zeros(T_raw-p,M*p);

if c==0 %no constant    
    j  = 0;
    ii = 1;
    for i=p:T_raw-1
        temp = flipdim(Ydata((1+j):i,:),1);
        Ylag(ii,:) = reshape(temp',1,p*M);
        j  = j + 1;
        ii = ii + 1;
    end
    Y = Ydata(p+1:T_raw,1:M);
else %constant    
    j  = 0;
    ii = 1;
    for i=p:T_raw-1
        temp = flipdim(Ydata((1+j):i,:),1);
        Ylag(ii,:) = reshape(temp',1,p*M);
        j  = j + 1;
        ii = ii + 1;
    end
    con = ones(T_raw-p,1);
    Ylag = [Ylag con]; 
    Y = Ydata(p+1:T_raw,1:M);
end

end %end function