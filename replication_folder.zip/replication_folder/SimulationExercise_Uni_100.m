clear
close all
clc

rng('default')

N = 5000;
T = 100;

%%
% Random Walk Model
true.y_rw = [];
true.c_rw = [];
filter.hp_rw = [];
filter.ham_rw = [];
stats.rw = [];

for ii = 1: N 
    %generate data
     true.c_rw(:,ii) = 0.933*randn(T,1);
     true.y_rw(:,ii) = cumsum(0.779 + true.c_rw(:,ii));
    
    %estimate cyclical component
    [~,filter.hp_rw(:,ii)] = hpfilter(true.y_rw(:,ii),1600);
    [filter.ham_rw(:,ii),~,~,~,~] = regfilter(true.y_rw(:,ii),8,4);
    
    %estimate statistics
    [stats.rw(ii,:) ] = fn_stats(true.c_rw(:,ii),filter.hp_rw(:,ii),filter.ham_rw(:,ii));
    
end
    
 [stats.rw_ind] = fn_ind(stats.rw);

%%
% Random Walk Model Hamilton
true.y_rw_ham = [];
true.c_rw_ham = [];
filter.hp_rw_ham = [];
filter.ham_rw_ham = [];
stats.rw_ham = [];

for ii = 1: N 
    %generate data
     true.c_rw_ham(:,ii) = 3.588522*randn(T,1);
     y = zeros(T,1);
     y(1:8) = true.c_rw_ham(1:8,ii);
     for jj = 9:T
     y(jj,1) = 6.232439 + y(jj-8,1) +  true.c_rw_ham(jj,ii);
     end
     true.y_rw_ham(:,ii) = y;

    %estimate cyclical component
    [~,filter.hp_rw_ham(:,ii)] = hpfilter(true.y_rw_ham(:,ii),1600);
    [filter.ham_rw_ham(:,ii),~,~,~,~] = regfilter(true.y_rw_ham(:,ii),8,4);
        
    %estimate statistics
    [stats.rw_ham(ii,:) ] = fn_stats(true.c_rw_ham(:,ii),filter.hp_rw_ham(:,ii),filter.ham_rw_ham(:,ii));

end
 [stats.rw_ham_ind] = fn_ind(stats.rw_ham);


%%
%Morley,Nelson,Zivot with correlation
true.y_mnz = [];
true.c_mnz =[];
filter.hp_mnz = [];
filter.ham_mnz = [];

%Morley
mu = 0.8156;
phi1 = 1.3418;
phi2 = -0.7059;
thet1 =  -1.0543;
thet2  = 0.5188;
sig2_u = 0.9694^2;

gam_0 = sig2_u*(1+thet1^2 + thet2^2);
gam_1 = sig2_u*(thet1)*(1+thet2);
gam_2 = sig2_u*thet2;

GAM = [gam_0;gam_1;gam_2];
PHI = [1+phi1^2+phi2^2 2 2*(1+phi1); -phi1*(1-phi2) -1 -(1-phi2 + phi1); -phi2 0 -phi2];
sig = inv(PHI)*GAM;
A = [sig(1) sig(3); sig(3) sig(2)];


for ii = 1:N
    y = zeros(T,1);
    dy = zeros(T,1);

    tau = zeros(T,1);
    c = zeros(T,1);
    u = sqrt(sig2_u)*randn(T,1);
    ETAEPS = randn(T,2)*chol(A);    
 
    for jj = 3:T
    tau(jj,1)= tau(jj-1,1) + mu + ETAEPS(jj,1);
    c(jj,1) = [phi2 phi1]*c(jj-2:jj-1,1) + ETAEPS(jj,2);
    y(jj,1) = tau(jj,1) + c(jj,1);
    
    end
    true.c_mnz(:,ii) = c;
    true.y_mnz(:,ii) = y;
    
    %estimate cyclical component
    [~,filter.hp_mnz(:,ii)] = hpfilter(true.y_mnz(:,ii),1600);
    [filter.ham_mnz(:,ii),~,~,~,~] = regfilter(true.y_mnz(:,ii),8,4);

    %estimate statistics
    [stats.mnz(ii,:) ] = fn_stats(true.c_mnz(:,ii),filter.hp_mnz(:,ii),filter.ham_mnz(:,ii));

end

 [stats.mnz_ind] = fn_ind(stats.mnz);

%%
%Morley,Nelson,Zivot without correlation
true.y_mnz_wo = [];
true.c_mnz_wo =[];
filter.hp_mnz_wo = [];
filter.ham_mnz_wo = [];

A = [0.3453 0; 0 0.3754];
phi1 = 1.5330;
phi2 = -0.5664;
mu = 0.7942;

for ii = 1:N
    y = zeros(T,1);
    dy = zeros(T,1);

    tau = zeros(T,1);
    c = zeros(T,1);
    ETAEPS = randn(T,2)*chol(A);    
 
    for jj = 3:T
    tau(jj,1)= tau(jj-1,1) + mu + ETAEPS(jj,1);
    c(jj,1) = [phi2 phi1]*c(jj-2:jj-1,1) + ETAEPS(jj,2);
    y(jj,1) = tau(jj,1) + c(jj,1);
    
    end
    true.c_mnz_wo(:,ii) = c;
    true.y_mnz_wo(:,ii) = y;
    
    %estimate cyclical component
    [~,filter.hp_mnz_wo(:,ii)] = hpfilter(true.y_mnz_wo(:,ii),1600);
    [filter.ham_mnz_wo(:,ii),~,~,~,~] = regfilter(true.y_mnz_wo(:,ii),8,4);
    
    %estimate statistics
    [stats.mnz_wo(ii,:) ] = fn_stats(true.c_mnz_wo(:,ii),filter.hp_mnz_wo(:,ii),filter.ham_mnz_wo(:,ii));

end

 [stats.mnz_wo_ind] = fn_ind(stats.mnz_wo);

%%
% Model with constant unconditional mean change in trend
rue.y_hod = [];
true.c_hod =[];
filter.hp_hod = [];
filter.ham_hod = [];

A = [0.002 0; 0 0.6385];

for ii = 1:N
    y = zeros(T,1);
    g = zeros(T,1);
    c = zeros(T,1);
    ETAEPS = randn(T,2)*chol(A);    
 
    for jj = 3:T
    g(jj,1)= g(jj-1,1) + 0.07786 + 0.900*(g(jj-1,1)-g(jj-2,1)) + ETAEPS(jj,1);
    c(jj,1) = [-0.45 1.25 ]*c(jj-2:jj-1,1) + ETAEPS(jj,2);
    y(jj,1) = g(jj,1) + c(jj,1);
    
    end
    true.c_hod(:,ii) = c;
    true.y_hod(:,ii) = y;
    
    %estimate cyclical component
    [~,filter.hp_hod(:,ii)] = hpfilter(true.y_hod(:,ii),1600);
    [filter.ham_hod(:,ii),~,~,~,~] = regfilter(true.y_hod(:,ii),8,4);
    
    %estimate statistics
    [stats.hod(ii,:) ] = fn_stats(true.c_hod(:,ii),filter.hp_hod(:,ii),filter.ham_hod(:,ii));

end

 [stats.hod_ind] = fn_ind(stats.hod);


%%
% Clark Model
rue.y_clark = [];
true.c_clark =[];
filter.hp_clark = [];
filter.ham_clark = [];

A = eye(3);

for ii = 1:N
    y = zeros(T,1);
    g = zeros(T,1);
    d = zeros(T,1);
    c = zeros(T,1);
    EPS = randn(T,3)*chol(A);    
 
    for jj = 3:T
    g(jj,1)= g(jj-1,1) +d(jj-1,1)  + 0.545*EPS(jj,1);
    d(jj,1) = d(jj-1,1) + 0.021*EPS(jj,2);
    c(jj,1) = [-0.565 1.510 ]*c(jj-2:jj-1,1) + 0.603*EPS(jj,3);
    y(jj,1) = g(jj,1) + c(jj,1);
    
    end
    true.c_clark(:,ii) = c;
    true.y_clark(:,ii) = y;
    
    %estimate cyclical component
    [~,filter.hp_clark(:,ii)] = hpfilter(true.y_clark(:,ii),1600);
    [filter.ham_clark(:,ii),~,~,~,~] = regfilter(true.y_clark(:,ii),8,4);
    
    %estimate statistics
    [stats.clark(ii,:) ] = fn_stats(true.c_clark(:,ii),filter.hp_clark(:,ii),filter.ham_clark(:,ii));

end

 [stats.clark_ind] = fn_ind(stats.clark);


 %%
 A = mean(stats.rw);
 B = mean(stats.rw_ham);
 C = mean(stats.mnz);
 D = mean(stats.mnz_wo);
 E = mean(stats.hod);
 F = mean(stats.clark);

 idx = [3 2 6 5 12 11 8 7 10 9];

 
 %% Table 1: 
 % (Avg.)
 table_mean = [reshape(A(idx),2,5)' reshape(C(idx),2,5)'  reshape(D(idx),2,5)' reshape(E(idx),2,5)' reshape(F(idx),2,5)']';
 % Score-Hamilton
 table_score_ham = [stats.rw_ind; stats.mnz_ind; stats.mnz_wo_ind; stats.hod_ind; stats.clark_ind];
 table_ave_score_ham = [mean(table_score_ham(:,1)), mean(table_score_ham(:,2)), mean(table_score_ham(:,3)), mean(table_score_ham(:,4)), mean(table_score_ham(:,5))];


Table6_paper = nan(12,10);
Table6_paper(1:10,[1 3 5 7 9]) = table_mean;
Table6_paper([1 3 5 7 9],[2 4 6 8 10]) = table_score_ham;
Table6_paper([2 4 6 8 10],[2 4 6 8 10]) = 1-table_score_ham;
Table6_paper([11 12],[2 4 6 8 10]) = [table_ave_score_ham;1-table_ave_score_ham];