%gain comparison
T=2024;
grid = 2*pi*(0:1:floor(T/2))/T;

     
        
        h=8;
        b1 = vars.b.reg1lQ(1);
        b2 = vars.b.reg1lQ(2);
        b3 = vars.b.reg1lQ(3);
        b4 = vars.b.reg1lQ(4);
        h_hr_1lQ = 1-b1*exp(-1i*grid*h)-b2*exp(-1i*grid*(h+1))-b3*exp(-1i*grid*(h+2))-b4*exp(-1i*grid*(h+3));


        b1 = vars.b.reg1CQ(1);
        b2 = vars.b.reg1CQ(2);
        b3 = vars.b.reg1CQ(3);
        b4 = vars.b.reg1CQ(4);
        h=8;
        
        h_hr_1CQ = 1-b1*exp(-1i*grid*h)-b2*exp(-1i*grid*(h+1))-b3*exp(-1i*grid*(h+2))-b4*exp(-1i*grid*(h+3));
       
        
        ds_times = 1./(2*(1-cos(grid')));

        
        %difference stationary
        %diff filter
        diff1_df_ptf = 2*(1-cos(grid*8))./(2*(1-cos(grid)));
 
        %hp filter
        hp1_df_ptf =  2*4*(1-cos(grid)).^3./(1/1600+4*(1-cos(grid)).^2).^2;
        
         
%% FIGURE 1: The cyclical properties of the Hodrick-Prescott filter

        T=1000;
        H = [zeros(T,2) eye(T)]; % procedure as given by Hamilton (2018) for y = (y_1,...,y_T)
        Q = toeplitz([1 zeros(1,T-1)],[1 -2 1 zeros(1,T-3)]);
        Q_bar = [Q [zeros(T-2,1); 1 ; -2] [zeros(T-1,1); 1]];
        A_inv = (H'*H + 1600*Q_bar'*Q_bar)\H';
   k=[-(T-1):0]';
    for ii =1:length(grid)
           tf_hp1s(1,ii) = 1- ones(1,length(k))*(A_inv(end,:)'.*exp(1i*grid(ii)*k)); %transfer function of HP-1s given t=T observations
    end
        %Derive phases
        
         %transfer function (HR see above)
         h1 = 1-exp(-1i*grid);
         h1_ = 1-exp(1i*grid);
         h8 = 1-exp(-1i*8*grid);
         lam=1600;
         h_hp_1 =   (lam*((h1.^2).*(h1_.^2)))./(1+lam*((h1.^2).*(h1_.^2)));


         %mark business cycle frequencies
        freq_low = 2*pi/(1.5*4);
        freq_high= 2*pi/(8*4);
        bus_freq = (grid <= freq_low) & (grid >= freq_high);
        
        freq_low_fc =  2*pi/(8*4);
        freq_high_fc = 2*pi/(30*4);
        fc_freq = (grid <= freq_low_fc) & (grid >= freq_high_fc);
        
        size_plot = [8/1.5 4/1.5];

        %% Figure 1 (a)

         figure
         maxl=1;
         hold on
        area(grid,bus_freq*maxl,'FaceColor',[175/255 197/255 221/255])
        area(grid,fc_freq*maxl,'FaceColor',[230/255 230/255 250/255])
        plot(grid,ones(length(h_hp_1),1).*bus_freq','-.','Color',[0 200/255 0],'LineWidth',3.5); %hp filter
        a1= plot(grid,abs(h_hp_1).^2,'Color',[0 0 0],'LineWidth',2); %quarterly
        a2=plot(grid,abs(tf_hp1s).^2,'--','Color',[1 0 0],'LineWidth',2); %yearly
        hold off
        L =length(grid);
        lab_x = [grid(1) grid(floor(L/4)) grid(floor(L/2)) grid(floor(3*L/4))  grid(end)];
        set(gca, 'XTick', lab_x , 'XTickLabel', {'0'; '\pi/4'; '\pi/2'; '3\pi/4'; '\pi'}, 'fontname', 'latex','fontsize', 12 )
        ylabel('PTF(\omega)','fontname','latex','fontsize', 11 )
        xlabel('Radians','fontname','latex','fontsize', 11 )
        axis tight
        set(gcf,'PaperPositionMode','manual')
        set(gcf,'PaperUnits','inches');
        set(gcf,'PaperPosition',[0 0 size_plot]);
        figfile = fullfile('figures', 'Figure_1a_Hodrick-Prescott filter_subplot');
        set(gcf, 'PaperSize', [size_plot(1,1)  size_plot(1,2)]); %Keep the same paper size
        saveas(gcf, figfile , 'pdf'); 

        %% Figure 1 (b)
        size_plot = [8/1.5 4/1.5];
        figure
        maxl = pi;
        minl = -pi;
        hold on
        area(grid,bus_freq*maxl,'FaceColor',[175/255 197/255 221/255])
        area(grid,bus_freq*minl,'FaceColor',[175/255 197/255 221/255])
        area(grid,fc_freq*maxl,'FaceColor',[230/255 230/255 250/255])
        area(grid,fc_freq*minl,'FaceColor',[230/255 230/255 250/255])
        a3 = plot(grid,zeros(length(h_hp_1),1),'-.','Color',[0 200/255 0],'LineWidth',3.5); %hp filter
        a1= plot(grid,angle(h_hp_1),'Color',[0 0 0],'LineWidth',2); %quarterly
        a2=plot(grid,angle(tf_hp1s),'--','Color',[1 0 0],'LineWidth',2); %yearly

        hold off
        L =length(grid);
        lab_x = [grid(1) grid(floor(L/4)) grid(floor(L/2)) grid(floor(3*L/4))  grid(end)];
        set(gca, 'XTick', lab_x , 'XTickLabel', {'0'; '\pi/4'; '\pi/2'; '3\pi/4'; '\pi'}, 'fontname', 'latex','fontsize', 12 )
        ylabel('\Theta( \omega)','fontname','latex','fontsize', 11 )
        xlabel('Radians','fontname','latex','fontsize', 11 )
        legend([a3,a1,a2],'Ideal band pass filter','Hodrick-Prescott filter','One-sided Hodrick-Prescott filter' ,'Location','north')
        legend boxoff

        axis tight
        ylim([-pi,pi])
        set(gca, 'YTick',-pi:(pi/2):pi,'YTickLabel', {'-\pi'; '-\pi/2'; '0'; '\pi/2'; '\pi'}, 'fontname', 'latex','fontsize', 12)
        set(gcf,'PaperPositionMode','manual')
        set(gcf,'PaperUnits','inches');
        set(gcf,'PaperPosition',[0 0 size_plot]);
        figfile = fullfile('figures', 'Figure_1b_One-sided Hodrick-Prescott filter_subplot' );
        set(gcf, 'PaperSize', [size_plot(1,1)  size_plot(1,2)]); %Keep the same paper size
        saveas(gcf, figfile , 'pdf'); 

%% FIGURE 2: The cyclical properties of the Hamilton filter when applied to data generated from a random walk, US log GDP and the US credit-to-GDP ratio   
         %fn_phase_figure_2(grid,h8,h_hr_1lQ,h_hr_1CQ,'Hamilton filter (rw)','Hamilton filter (GDP)','Hamilton filter (credit/GDP)')
%% Figure 2 (a)
         figure
         maxl=max((abs([h_hr_1lQ(:) ;h_hr_1CQ(:)]).^2));
         hold on
        area(grid,bus_freq*maxl,'FaceColor',[175/255 197/255 221/255])
        area(grid,fc_freq*maxl,'FaceColor',[230/255 230/255 250/255])
        a3 = plot(grid,ones(length(h8),1).*bus_freq','-.','Color',[0 200/255 0],'LineWidth',3.5); %hp filter
        a1= plot(grid,abs(h8).^2,'Color',[0 0 0],'LineWidth',2); %quarterly
        a2=plot(grid,abs(h_hr_1lQ).^2,'--','Color',[1 0 0],'LineWidth',2); %yearly
        a4=plot(grid,abs(h_hr_1CQ).^2,'-.','Color',[0 0 1],'LineWidth',2); %yearly

        hold off
        L =length(grid);
        lab_x = [grid(1) grid(floor(L/4)) grid(floor(L/2)) grid(floor(3*L/4))  grid(end)];
        set(gca, 'XTick', lab_x , 'XTickLabel', {'0'; '\pi/4'; '\pi/2'; '3\pi/4'; '\pi'}, 'fontname', 'latex','fontsize', 12 )
        ylabel('PTF(\omega)','fontname','latex','fontsize', 11 )
        xlabel('Radians','fontname','latex','fontsize', 11 )
             legend([a3,a1,a2,a4],'Ideal band pass filter','Hamilton filter (rw)','Hamilton filter (GDP)','Hamilton filter (credit/GDP)')
        legend boxoff

        axis tight
         set(gca, 'YTick',0:floor(maxl/4):maxl)
        set(gcf,'PaperPositionMode','manual')
        set(gcf,'PaperUnits','inches');
        set(gcf,'PaperPosition',[0 0 size_plot]);
        figfile = fullfile('figures','Figure_2a_Hamilton filter (rw)_subplot');
        set(gcf, 'PaperSize', [size_plot(1,1)  size_plot(1,2)]); %Keep the same paper size
        saveas(gcf, figfile , 'pdf'); 

       
        %% Figure 2 (b)
        figure
         maxl=max((abs([h_hr_1lQ(:) ;h_hr_1CQ(:)]).^2));
         maxl=1;
         hold on
        area(grid,bus_freq*maxl,'FaceColor',[175/255 197/255 221/255])
        area(grid,fc_freq*maxl,'FaceColor',[230/255 230/255 250/255])
        a3 = plot(grid,ones(length(h8),1).*bus_freq','-.','Color',[0 200/255 0],'LineWidth',3.5); %hp filter
        a1= plot(grid,abs(h8).^2,'Color',[0 0 0],'LineWidth',2); %quarterly
        a2=plot(grid,abs(h_hr_1lQ).^2,'--','Color',[1 0 0],'LineWidth',2); %yearly
        a4=plot(grid,abs(h_hr_1CQ).^2,'-.','Color',[0 0 1],'LineWidth',2); %yearly

        hold off
        L =length(grid);
        lab_x = [grid(1) grid(floor(L/4)) grid(floor(L/2)) grid(floor(3*L/4))  grid(end)];
        set(gca, 'XTick', lab_x , 'XTickLabel', {'0'; '\pi/4'; '\pi/2'; '3\pi/4'; '\pi'}, 'fontname', 'latex','fontsize', 12 )
        ylabel('PTF(\omega)','fontname','latex','fontsize', 11 )
        xlabel('Radians','fontname','latex','fontsize', 11 )
         ylim([0,1])
        xlim([0,pi])

        set(gcf,'PaperPositionMode','manual')
        set(gcf,'PaperUnits','inches');
        set(gcf,'PaperPosition',[0 0 size_plot]);
        figfile = fullfile('figures', 'Figure_2b_Hamilton filter (GDP)_subplot');
        set(gcf, 'PaperSize', [size_plot(1,1)  size_plot(1,2)]); %Keep the same paper size
        saveas(gcf, figfile , 'pdf'); 

        %% Figure 2 (c)
        figure
        maxl = pi;
        minl = -pi;
                hold on
        area(grid,bus_freq*maxl,'FaceColor',[175/255 197/255 221/255])
        area(grid,bus_freq*minl,'FaceColor',[175/255 197/255 221/255])
        area(grid,fc_freq*maxl,'FaceColor',[230/255 230/255 250/255])
        area(grid,fc_freq*minl,'FaceColor',[230/255 230/255 250/255])
        a3 = plot(grid,zeros(length(h8),1),'-.','Color',[0 200/255 0],'LineWidth',3.5); %hp filter
        a1= plot(grid,angle(h8),'Color',[0 0 0],'LineWidth',2); %quarterly
        a2=plot(grid,angle(h_hr_1lQ),'--','Color',[1 0 0],'LineWidth',2); %yearly
        a4=plot(grid,angle(h_hr_1CQ),'-.','Color',[0 0 1],'LineWidth',2); %yearly

        hold off
        L =length(grid);
        lab_x = [grid(1) grid(floor(L/4)) grid(floor(L/2)) grid(floor(3*L/4))  grid(end)];
        set(gca, 'XTick', lab_x , 'XTickLabel', {'0'; '\pi/4'; '\pi/2'; '3\pi/4'; '\pi'}, 'fontname', 'latex','fontsize', 12 )
        ylabel('\Theta( \omega)','fontname','latex','fontsize', 11 )
        xlabel('Radians','fontname','latex','fontsize', 11 )

        axis tight
        ylim([-pi,pi])
        set(gca, 'YTick',-pi:(pi/2):pi,'YTickLabel', {'-\pi'; '-\pi/2'; '0'; '\pi/2'; '\pi'}, 'fontname', 'latex','fontsize', 12)
        
        set(gcf,'PaperPositionMode','manual')
        set(gcf,'PaperUnits','inches');
        set(gcf,'PaperPosition',[0 0 size_plot]);
        figfile = fullfile('figures', 'Figure_2c_Hamilton filter(credit-to-GDP)_subplot');
        set(gcf, 'PaperSize', [size_plot(1,1)  size_plot(1,2)]); %Keep the same paper size
        saveas(gcf, figfile , 'pdf'); 














%% FIGURE 3: Spectral density a HP filtered random walk and a Hamilton-filtered random walk        
       
        %lam =1600 and hamilton      

        figure
        hold on
        scl=70;
        area(grid,bus_freq*scl,'FaceColor',[175/255 197/255 221/255])
        area(grid,fc_freq*scl,'FaceColor',[230/255 230/255 250/255])
        a1 = plot(grid,ds_times./(2*pi),'-','Color',[0 0 1],'LineWidth',1); %hp filter
        a2= plot(grid,hp1_df_ptf./(2*pi),'-','Color',[0 0 0],'LineWidth',2); %hp filter
        a3= plot(grid,diff1_df_ptf./(2*pi),'--','Color',[1 0 0],'LineWidth',2);
        leg1 = legend([a1,a2,a3],'Random walk (rw)','Hodrick-Prescott-filtered rw','Hamilton-filtered rw','Location','north');
        legend boxoff


        hold off
        L =length(grid);
        lab_x = [grid(1) grid(floor(L/4)) grid(floor(L/2)) grid(floor(3*L/4))  grid(end)];
        set(gca, 'XTick', lab_x , 'XTickLabel', {'0'; '\pi/4'; '\pi/2'; '3\pi/4'; '\pi'}, 'fontname', 'latex','fontsize', 12 )
        ylabel('S(\omega)','fontname','latex','fontsize', 11 )
        xlabel('Radians','fontname','latex','fontsize', 11 )
        axis tight
        ylim([0,12]);
        set(gcf,'PaperPositionMode','manual')
        set(gcf,'PaperUnits','inches');
        set(gcf,'PaperPosition',[0 0 size_plot]);
        figfile = fullfile('figures', 'Figure_3_Spectral_density');
        saveas(gcf, figfile , 'pdf');
       

