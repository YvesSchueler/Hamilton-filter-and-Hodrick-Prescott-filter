clear 
close all


% load data
[Y1,TXT1,~] =   xlsread('data/data_hamilton_2019.xlsx','Tabelle1'); 
[Y2,TXT2,~] =   xlsread('data/Revision_TimeSeries.xlsx','Final'); 

vnames = {'GDP','Credit-to-GDP','Consumption','Investment','Hours worked','Wage','Interest rate','Inflation','Unemployment rate'};
Y =  [log(Y1(:,1))*100 Y1(:,2) log(Y2(:,1:3))*100 log(Y2(:,5)./Y2(:,6))*100 Y2(:,4) log(Y2(:,6))*100 Y2(:,7)];
nber = Y1(:,3);
date_max = datetime(TXT1(2:end,1),'InputFormat','dd.MM.yy');


idx_vars = [1 3 4 9 5 6 7 8 2];
vnames = vnames(:,idx_vars);
Y = Y(:,idx_vars);

[T,K] = size(Y);

vars.hp = nan(T,K);
vars.hp_1s = nan(T,K);
vars.h = nan(T,K);

for ii = 1:K
[~,vars.hp(~isnan(Y(:,ii)),ii)] = hpfilter(Y(~isnan(Y(:,ii)),ii),1600);
[ vars.hp_1s(~isnan(Y(:,ii)),ii), ~, ~ ] = adj1s_hpfilter(Y(~isnan(Y(:,ii)),ii),1600);
[vars.h(~isnan(Y(:,ii)),ii),~,~,~,~,~] = regfilter(Y(~isnan(Y(:,ii)),ii),8,4);
end

idx_table = ~isnan(vars.hp.*vars.h); 
vars.hp1 = nan(size(vars.hp));
vars.hp1(idx_table) = vars.hp(idx_table);
%vol
stat.std_hp = nanstd(vars.hp1);
stat.std_hp(2,:) = stat.std_hp./stat.std_hp(1,1);

stat.std_h = nanstd(vars.h);
stat.std_h(2,:) = stat.std_h./stat.std_h(1,1);


%persistence
stat.pers_hp = nan(4,9);
stat.pers_h =nan(4,9);

for ii = 1:K

   [b1, ~, pval_ones, ~, ~, ~, ~, ~] = olsnw(vars.hp1(2:end,ii),vars.hp1(1:end-1,ii),1); %lag1
   [b2, ~, pval_ones, ~, ~, ~, ~, ~] = olsnw(vars.hp1(3:end,ii),vars.hp1(1:end-2,ii),1); %lag2
   [b3, ~, pval_ones, ~, ~, ~, ~, ~] = olsnw(vars.hp1(4:end,ii),vars.hp1(1:end-3,ii),1); %lag3
   [b4, ~, pval_ones, ~, ~, ~, ~, ~] = olsnw(vars.hp1(5:end,ii),vars.hp1(1:end-4,ii),1); %lag4
   stat.pers_hp(:,ii) = [b1(2); b2(2); b3(2); b4(2)];

   [b1, ~, pval_ones, ~, ~, ~, ~, ~] = olsnw(vars.h(2:end,ii),vars.h(1:end-1,ii),1);
   [b2, ~, pval_ones, ~, ~, ~, ~, ~] = olsnw(vars.h(3:end,ii),vars.h(1:end-2,ii),1);
   [b3, ~, pval_ones, ~, ~, ~, ~, ~] = olsnw(vars.h(4:end,ii),vars.h(1:end-3,ii),1); 
   [b4, ~, pval_ones, ~, ~, ~, ~, ~] = olsnw(vars.h(5:end,ii),vars.h(1:end-4,ii),1);
   stat.pers_h(:,ii) = [b1(2); b2(2); b3(2); b4(2)];

end

%corr with GDP
stat.corr_hp = nan(9,8);
stat.corr_h  = nan(9,8);

for ii = 1:K

[stat.corr_hp(:,ii),lags] = fn_nancorr(vars.hp1(:,1),vars.hp1(:,ii));
[stat.corr_h(:,ii),lags]  = fn_nancorr(vars.h(:,1),vars.h(:,ii));

end


Table4_paper=nan(14,9);
Table4_paper = [stat.std_h; stat.std_hp; stat.pers_h(1:2,:); stat.pers_hp(1:2,:);stat.corr_h(4:6,:);stat.corr_hp(4:6,:)];


%%
%%make plots 

ret=1;
dateFormat=11;
size_plot = [5 2.5];

for ii = 1:K

figure    
hold on
if ii ~=9
area(date_max,nber*max(vars.h(:,ii)*2),'LineStyle','none','FaceColor',[0.7 0.7 0.7]);
area(date_max,nber*min(vars.h(:,ii)*2),'LineStyle','none','FaceColor',[0.7 0.7 0.7]);
end
ax2 = plot(date_max,vars.hp(:,ii) ,'LineWidth',2,'Color',[1 0 0]);
ax4 = plot(date_max,vars.h(:,ii) ,'LineWidth',2,'Color',[0 0 0]);
plot(date_max,zeros(size(date_max,1)),'--','Color',[0 0 0],'LineWidth',0.5)
axis tight
xData = date_max(13:20:end);
xlim([date_max(1) date_max(end)])
ylim([min(vars.h(:,ii)) max(vars.h(:,ii))])
set(gca,'XTick',[xData])
datetick('x',dateFormat,'keeplimits','keepticks');
hold off
if ii == 1
legend([ax4,ax2],'Hamilton','Hodrick-Prescott','Location','northeast')
legend boxoff
end
set(gcf,'PaperPositionMode','manual')
set(gcf,'PaperUnits','inches');
set(gcf,'PaperPosition',[0 0 size_plot]);
figfile = fullfile('figures', vnames{1,ii});
set(gcf, 'PaperSize', [size_plot(1,1)  size_plot(1,2)]); %Keep the same paper size
saveas(gcf, figfile , 'pdf'); 

end




%% H filter
figure    
hold on
% Plot the NBER shaded areas first so they are in the background
area(date_max, nber*max(vars.h(:)*2), 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]);
area(date_max, nber*min(vars.h(:)*2), 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]); % Overlap with white to simulate "no shading"

% Loop through all indicators
for ii = [2:K 1]
    if ii == 1
        % Plot the first indicator as a black thick line
    ax =  plot(date_max, vars.h(:,ii), 'k', 'LineWidth', 2);
    elseif ii == [4]
       plot(date_max, -vars.h(:,ii), 'Color', [0, 0.6, 0], 'LineWidth', 0.5);
    else
        % Plot other indicators as tiny green lines
        plot(date_max, vars.h(:,ii), 'Color', [0, 0.6, 0], 'LineWidth', 0.5);
    end
end

% Plot the zero line
plot(date_max, zeros(size(date_max,1)), '--k', 'LineWidth', 0.5)

% Customize the plot
axis tight
xData = date_max(1:16:end);
xlim([date_max(1) date_max(end)])
ylim([nanmin(vars.h(:)) nanmax(vars.h(:))]) % Set the y-limits to include all data
set(gca, 'XTick', [xData])
datetick('x', dateFormat, 'keeplimits', 'keepticks')
hold off

% Add a legend for the first indicator
legend([ax],'H-filtered log GDP' ,'Location','northeast')

legend boxoff

% Set the figure properties for saving to file
set(gcf, 'PaperPositionMode', 'manual')
set(gcf, 'PaperUnits', 'inches')
set(gcf, 'PaperPosition', [0 0 size_plot])
set(gcf, 'PaperSize', [size_plot(1,1) size_plot(1,2)]) % Keep the same paper size

% Save the figure
figfile = fullfile('figures', 'all_indicators_h');
saveas(gcf, figfile, 'pdf'); 

%% HP filter
figure    
hold on
% Plot the NBER shaded areas first so they are in the background
area(date_max, nber*max(vars.hp(:)*2), 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]);
area(date_max, nber*min(vars.hp(:)*2), 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]); % Overlap with white to simulate "no shading"

% Loop through all indicators
for ii = [2:K 1]
    if ii == 1
        % Plot the first indicator as a black thick line
    ax =  plot(date_max, vars.hp(:,ii), 'k', 'LineWidth', 2);
    elseif ii == [4 8]
       plot(date_max, -vars.hp(:,ii), 'Color', [0, 0.6, 0], 'LineWidth', 0.5);
    else
        % Plot other indicators as tiny green lines
        plot(date_max, vars.hp(:,ii), 'Color', [0, 0.6, 0], 'LineWidth', 0.5);
    end
end

% Plot the zero line
plot(date_max, zeros(size(date_max,1)), '--k', 'LineWidth', 0.5)

% Customize the plot
axis tight
xData = date_max(1:16:end);
xlim([date_max(1) date_max(end)])
ylim([nanmin(vars.hp(:)) nanmax(vars.hp(:))]) % Set the y-limits to include all data
set(gca, 'XTick', [xData])
datetick('x', dateFormat, 'keeplimits', 'keepticks')
hold off

% Add a legend for the first indicator
legend([ax],'HP-filtered log GDP' ,'Location','northeast')

legend boxoff

% Set the figure properties for saving to file
set(gcf, 'PaperPositionMode', 'manual')
set(gcf, 'PaperUnits', 'inches')
set(gcf, 'PaperPosition', [0 0 size_plot])
set(gcf, 'PaperSize', [size_plot(1,1) size_plot(1,2)]) % Keep the same paper size

% Save the figure
figfile = fullfile('figures', 'all_indicators_hp');
saveas(gcf, figfile, 'pdf');

%% business cycle phase plots
size_plot = [5 3.5];

%select all BC indicators and switch sign off unemployment rate... Deleted
%inflation and credit to gdp
sel_bc = [ones(T,3) -1*ones(T,1) ones(T,3)];



BCycle_hp = sel_bc.*vars.hp(:,1:7);
BCycle_hp_1s = sel_bc.*vars.hp_1s(:,1:7);
BCycle_h = sel_bc.*vars.h(:,1:7);

p_rec_hp = nan(T,1);
p_rec_hp_1s = nan(T,1);
p_rec_h = nan(T,1);


%New: Expansion, Recession, Depression, Recovery
p_exp_hp = nan(T,1);
p_exp_hp_1s = nan(T,1);
p_exp_h = nan(T,1);

p_rece_hp = nan(T,1);
p_rece_hp_1s = nan(T,1);
p_rece_h = nan(T,1);

p_dep_hp = nan(T,1);
p_dep_hp_1s = nan(T,1);
p_dep_h = nan(T,1);

p_reco_hp = nan(T,1);
p_reco_hp_1s = nan(T,1);
p_reco_h = nan(T,1);

%percent of indicators above 0 
for ii= 1:T
p_rec_hp(ii,1) = mean(BCycle_hp(ii,~isnan(BCycle_hp(ii,:)))>0,2);
p_rec_hp_1s(ii,1) = mean(BCycle_hp_1s(ii,~isnan(BCycle_hp_1s(ii,:)))>0,2);
p_rec_h(ii,1) = mean(BCycle_h(ii,~isnan(BCycle_h(ii,:)))>0,2);
end



%percent of indicators in expansion ( >0 && first difference positive)
for ii= 2:T
p_exp_hp(ii,1) = mean((diff(BCycle_hp([ii-1 ii],~isnan(BCycle_hp(ii-1,:))))>0).*((BCycle_hp(ii,~isnan(BCycle_hp(ii-1,:))))>0),2);
p_exp_hp_1s(ii,1) = mean((diff(BCycle_hp_1s([ii-1 ii],~isnan(BCycle_hp_1s(ii-1,:))))>0).*((BCycle_hp_1s(ii,~isnan(BCycle_hp_1s(ii-1,:))))>0),2);
p_exp_h(ii,1) = mean((diff(BCycle_h([ii-1 ii],~isnan(BCycle_h(ii-1,:))))>0).*((BCycle_h(ii,~isnan(BCycle_h(ii-1,:))))>0),2);
end


%percent of indicators in recession ( >0 && first difference negative)
for ii= 2:T
p_rece_hp(ii,1) = mean((diff(BCycle_hp([ii-1 ii],~isnan(BCycle_hp(ii-1,:))))<0).*((BCycle_hp(ii,~isnan(BCycle_hp(ii-1,:))))>0),2);
p_rece_hp_1s(ii,1) = mean((diff(BCycle_hp_1s([ii-1 ii],~isnan(BCycle_hp_1s(ii-1,:))))<0).*((BCycle_hp_1s(ii,~isnan(BCycle_hp_1s(ii-1,:))))>0),2);
p_rece_h(ii,1) = mean((diff(BCycle_h([ii-1 ii],~isnan(BCycle_h(ii-1,:))))<0).*((BCycle_h(ii,~isnan(BCycle_h(ii-1,:))))>0),2);
end


%percent of indicators in depression ( < 0 && first difference negative)
for ii= 2:T
p_dep_hp(ii,1) = mean((diff(BCycle_hp([ii-1 ii],~isnan(BCycle_hp(ii-1,:))))<0).*((BCycle_hp(ii,~isnan(BCycle_hp(ii-1,:))))<0),2);
p_dep_hp_1s(ii,1) = mean((diff(BCycle_hp_1s([ii-1 ii],~isnan(BCycle_hp_1s(ii-1,:))))<0).*((BCycle_hp_1s(ii,~isnan(BCycle_hp_1s(ii-1,:))))<0),2);
p_dep_h(ii,1) = mean((diff(BCycle_h([ii-1 ii],~isnan(BCycle_h(ii-1,:))))<0).*((BCycle_h(ii,~isnan(BCycle_h(ii-1,:))))<0),2);
end



%percent of indicators in depression ( < 0 && first difference pos)
for ii= 2:T
p_reco_hp(ii,1) = mean((diff(BCycle_hp([ii-1 ii],~isnan(BCycle_hp(ii-1,:))))>0).*((BCycle_hp(ii,~isnan(BCycle_hp(ii-1,:))))<0),2);
p_reco_hp_1s(ii,1) = mean((diff(BCycle_hp_1s([ii-1 ii],~isnan(BCycle_hp_1s(ii-1,:))))>0).*((BCycle_hp_1s(ii,~isnan(BCycle_hp_1s(ii-1,:))))<0),2);
p_reco_h(ii,1) = mean((diff(BCycle_h([ii-1 ii],~isnan(BCycle_h(ii-1,:))))>0).*((BCycle_h(ii,~isnan(BCycle_h(ii-1,:))))<0),2);
end


p_rec_1_hp = p_rec_hp(nber==1,:);
p_rec_0_hp = p_rec_hp(nber==0,:);

p_rec_1_h = p_rec_h(nber==1,:);
p_rec_0_h = p_rec_h(nber==0,:);



% Expansion

% JOINT PLOT
% H filter
figure 
subplot(2,1,1)
title('Hamilton')
%ylabel('% of indicicators \\ signaling expansion') % Y-axis label
ylabel({'% of indicators'; 'signalling expansion'});
hold on
% Plot the NBER shaded areas first so they are in the background
area(date_max, nber*2, 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]);
area(date_max, nber*-1, 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]); % Overlap with white to simulate "no shading"
ax = area(date_max, p_exp_h, 'LineStyle', '-', 'FaceColor', [0 0 0]); % Overlap with white to simulate "no shading"
ax.FaceAlpha = 0.5;
%ax =  plot(date_max, p_rec_hp, 'k', 'LineWidth', 2);
axis tight
xData = date_max(13:20:end);
xlim([date_max(1) date_max(end)])
ylim([0 1]) % Set the y-limits to include all data
set(gca, 'XTick', [xData])
datetick('x', dateFormat, 'keeplimits', 'keepticks')
hold off

% HP filter
subplot(2,1,2)
title('Hodrick-Prescott')
%ylabel('% of indic. signal. expansion') % Y-axis label
ylabel({'% of indicators'; 'signalling expansion'});
hold on
% Plot the NBER shaded areas first so they are in the background
area(date_max, nber*2, 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]);
area(date_max, nber*-1, 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]); % Overlap with white to simulate "no shading"
ax = area(date_max, p_exp_hp, 'LineStyle', '-', 'FaceColor', [0.5 0 0]); % Overlap with white to simulate "no shading"
ax.FaceAlpha = 0.5;
%ax =  plot(date_max, p_rec_h, 'k', 'LineWidth', 2);
axis tight
xData = date_max(13:20:end);
xlim([date_max(1) date_max(end)])
ylim([0 1]) % Set the y-limits to include all data
set(gca, 'XTick', [xData])
datetick('x', dateFormat, 'keeplimits', 'keepticks')
hold off

% Set the figure properties for saving to file
set(gcf, 'PaperPositionMode', 'manual')
set(gcf, 'PaperUnits', 'inches')
set(gcf, 'PaperPosition', [0 0 size_plot])
set(gcf, 'PaperSize', [size_plot(1,1) size_plot(1,2)]) % Keep the same paper size

% Save the figure
figfile = fullfile('figures', 'BC_exp_prob_plot');
saveas(gcf, figfile, 'pdf');


% Recession

% JOINT PLOT
% H filter
figure 
subplot(2,1,1)
title('Hamilton')
%ylabel('% of indicicators \\ signaling expansion') % Y-axis label
ylabel({'% of indicators'; 'signalling recession'});
hold on
% Plot the NBER shaded areas first so they are in the background
area(date_max, nber*2, 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]);
area(date_max, nber*-1, 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]); % Overlap with white to simulate "no shading"
ax = area(date_max, p_rece_h, 'LineStyle', '-', 'FaceColor', [0 0 0]); % Overlap with white to simulate "no shading"
ax.FaceAlpha = 0.5;
%ax =  plot(date_max, p_rec_hp, 'k', 'LineWidth', 2);
axis tight
xData = date_max(13:20:end);
xlim([date_max(1) date_max(end)])
ylim([0 1]) % Set the y-limits to include all data
set(gca, 'XTick', [xData])
datetick('x', dateFormat, 'keeplimits', 'keepticks')
hold off

% HP filter
subplot(2,1,2)
title('Hodrick-Prescott')
%ylabel('% of indic. signal. expansion') % Y-axis label
ylabel({'% of indicators'; 'signalling recession'});
hold on
% Plot the NBER shaded areas first so they are in the background
area(date_max, nber*2, 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]);
area(date_max, nber*-1, 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]); % Overlap with white to simulate "no shading"
ax = area(date_max, p_rece_hp, 'LineStyle', '-', 'FaceColor', [0.5 0 0]); % Overlap with white to simulate "no shading"
ax.FaceAlpha = 0.5;
%ax =  plot(date_max, p_rec_h, 'k', 'LineWidth', 2);
axis tight
xData = date_max(13:20:end);
xlim([date_max(1) date_max(end)])
ylim([0 1]) % Set the y-limits to include all data
set(gca, 'XTick', [xData])
datetick('x', dateFormat, 'keeplimits', 'keepticks')
hold off

% Set the figure properties for saving to file
set(gcf, 'PaperPositionMode', 'manual')
set(gcf, 'PaperUnits', 'inches')
set(gcf, 'PaperPosition', [0 0 size_plot])
set(gcf, 'PaperSize', [size_plot(1,1) size_plot(1,2)]) % Keep the same paper size

% Save the figure
figfile = fullfile('figures', 'BC_rece_prob_plot');
saveas(gcf, figfile, 'pdf');

% Depression

% JOINT PLOT
% H filter
figure 
subplot(2,1,1)
title('Hamilton')
%ylabel('% of indicicators \\ signaling expansion') % Y-axis label
ylabel({'% of indicators'; 'signalling depression'});
hold on
% Plot the NBER shaded areas first so they are in the background
area(date_max, nber*2, 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]);
area(date_max, nber*-1, 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]); % Overlap with white to simulate "no shading"
ax = area(date_max, p_dep_h, 'LineStyle', '-', 'FaceColor', [0 0 0]); % Overlap with white to simulate "no shading"
ax.FaceAlpha = 0.5;
%ax =  plot(date_max, p_rec_hp, 'k', 'LineWidth', 2);
axis tight
xData = date_max(13:20:end);
xlim([date_max(1) date_max(end)])
ylim([0 1]) % Set the y-limits to include all data
set(gca, 'XTick', [xData])
datetick('x', dateFormat, 'keeplimits', 'keepticks')
hold off

% HP filter
subplot(2,1,2)
title('Hodrick-Prescott')
%ylabel('% of indic. signal. expansion') % Y-axis label
ylabel({'% of indicators'; 'signalling depression'});
hold on
% Plot the NBER shaded areas first so they are in the background
area(date_max, nber*2, 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]);
area(date_max, nber*-1, 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]); % Overlap with white to simulate "no shading"
ax = area(date_max, p_dep_hp, 'LineStyle', '-', 'FaceColor', [0.5 0 0]); % Overlap with white to simulate "no shading"
ax.FaceAlpha = 0.5;
%ax =  plot(date_max, p_rec_h, 'k', 'LineWidth', 2);
axis tight
xData = date_max(13:20:end);
xlim([date_max(1) date_max(end)])
ylim([0 1]) % Set the y-limits to include all data
set(gca, 'XTick', [xData])
datetick('x', dateFormat, 'keeplimits', 'keepticks')
hold off

% Set the figure properties for saving to file
set(gcf, 'PaperPositionMode', 'manual')
set(gcf, 'PaperUnits', 'inches')
set(gcf, 'PaperPosition', [0 0 size_plot])
set(gcf, 'PaperSize', [size_plot(1,1) size_plot(1,2)]) % Keep the same paper size

% Save the figure
figfile = fullfile('figures', 'BC_dep_prob_plot');
saveas(gcf, figfile, 'pdf');

% Recovery

% JOINT PLOT
% H filter
figure 
subplot(2,1,1)
title('Hamilton')
%ylabel('% of indicicators \\ signaling expansion') % Y-axis label
ylabel({'% of indicators'; 'signalling recovery'});
hold on
% Plot the NBER shaded areas first so they are in the background
area(date_max, nber*2, 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]);
area(date_max, nber*-1, 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]); % Overlap with white to simulate "no shading"
ax = area(date_max, p_reco_h, 'LineStyle', '-', 'FaceColor', [0 0 0]); % Overlap with white to simulate "no shading"
ax.FaceAlpha = 0.5;
%ax =  plot(date_max, p_rec_hp, 'k', 'LineWidth', 2);
axis tight
xData = date_max(13:20:end);
xlim([date_max(1) date_max(end)])
ylim([0 1]) % Set the y-limits to include all data
set(gca, 'XTick', [xData])
datetick('x', dateFormat, 'keeplimits', 'keepticks')
hold off

% HP filter
subplot(2,1,2)
title('Hodrick-Prescott')
%ylabel('% of indic. signal. expansion') % Y-axis label
ylabel({'% of indicators'; 'signalling recovery'});
hold on
% Plot the NBER shaded areas first so they are in the background
area(date_max, nber*2, 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]);
area(date_max, nber*-1, 'LineStyle', 'none', 'FaceColor', [0.7 0.7 0.7]); % Overlap with white to simulate "no shading"
ax = area(date_max, p_reco_hp, 'LineStyle', '-', 'FaceColor', [0.5 0 0]); % Overlap with white to simulate "no shading"
ax.FaceAlpha = 0.5;
%ax =  plot(date_max, p_rec_h, 'k', 'LineWidth', 2);
axis tight
xData = date_max(13:20:end);
xlim([date_max(1) date_max(end)])
ylim([0 1]) % Set the y-limits to include all data
set(gca, 'XTick', [xData])
datetick('x', dateFormat, 'keeplimits', 'keepticks')
hold off

% Set the figure properties for saving to file
set(gcf, 'PaperPositionMode', 'manual')
set(gcf, 'PaperUnits', 'inches')
set(gcf, 'PaperPosition', [0 0 size_plot])
set(gcf, 'PaperSize', [size_plot(1,1) size_plot(1,2)]) % Keep the same paper size

% Save the figure
figfile = fullfile('figures', 'BC_reco_prob_plot');
saveas(gcf, figfile, 'pdf');



