function [ out,lags ] = fn_nancorr(y,x)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
 idx = ~isnan(prod([y x],2));
 
 [out,lags] = crosscorr(y(idx,:),x(idx,:),'NumLags',4);

end

