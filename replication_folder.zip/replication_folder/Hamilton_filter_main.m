clear 
close all



%% load data
[Y1,TXT1,~] = xlsread('data/data_hamilton_2019.xlsx','Tabelle1'); %bond prices


Y_fin = Y1(:,2);
Y_bus = Y1(:,1);
nber = Y1(:,3);
date_max = datetime(TXT1(2:end,1),'InputFormat','dd.MM.yy');


[T,K] = size(Y_fin);


load 'data\all_co_abbrev.mat'


% transform to required versions and subsamples
[vars ] = fn_transform_v4(Y_fin,Y_bus,T);


%% FIGURES 1-3

run gain1.m


