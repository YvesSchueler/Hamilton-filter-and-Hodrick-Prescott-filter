function [ tests ] = fn_plot_biUC4(stats,name,sel_leg) 

test = stats(1,:);
  test1 = stats(2,:);
    test2 = stats(3,:);
size_plot = [8/1.5 4/1.5];
figure
a1 = stem([-4.1:1:3.9]',test','filled','g-.o');
hold on
a2 = stem([-4:4]',test2','filled','k-o');
a3 = stem([-3.9:1:4.1]',test1','filled','r--o');

grid('on')
xlabel('Lag of GDP')
ylabel('Average cross-correlation')
hold('on')
axis tight
if sel_leg == 1
legend([a1,a2,a3],'True','Hamilton','Hodrick-Prescott' ,'Location','southwest')
legend boxoff
end
set(gcf,'PaperPositionMode','manual')
set(gcf,'PaperUnits','inches');
set(gcf,'PaperPosition',[0 0 size_plot]);
figfile = fullfile('figures', [name]);
set(gcf, 'PaperSize', [size_plot(1,1)  size_plot(1,2)]); %Keep the same paper size
saveas(gcf, figfile , 'pdf'); 
tests = 1;
end