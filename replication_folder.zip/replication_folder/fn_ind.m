function [ out ] = fn_ind( stats )
%How many times Hamilton filter closer to true cycle?

   rel_sig = mean(abs(stats(:,3))<=abs(stats(:,2)));
   rel_gam = mean(abs(stats(:,6)) <= abs(stats(:,5)));
   rel_cor =  mean(stats(:,12) >= stats(:,11));
   rel_RMSE = mean(stats(:,8) <= stats(:,7));
   rel_rtRMSE = mean(stats(:,10) <= stats(:,9));

  out = [rel_sig rel_gam rel_cor rel_RMSE rel_rtRMSE];

end

