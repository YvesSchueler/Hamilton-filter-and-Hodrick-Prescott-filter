clear
close all
clc

rng('default')




N = 5000;
T = 100;

%%
% Bivariate Random Walk Model (GDP and Credit to GDP)
true.y_rw = [];
true.c_rw = [];
filter.hp_rw = [];
filter.ham_rw = [];
stats.rw = [];
A = [0.8707956	0.004658996; 0.004658996	0.765195206];

for ii = 1: N 
    %generate data
     true.c_rw =randn(T,2)*chol(A);
     true.y_rw = cumsum(ones(T,1)*[0.779472 0.361404] + true.c_rw);
    
    %estimate cyclical component
    [~,filter.hp_rw] = hpfilter(true.y_rw,1600);
    [filter.ham_rw(:,1),~,~,~,~] = regfilter(true.y_rw(:,1),8,4);
    [filter.ham_rw(:,2),~,~,~,~] = regfilter(true.y_rw(:,2),8,4);

    %estimate statistics
    [stats.rw(ii,:),stats.rw1(ii,:) ] = fn_stats_bi(true.c_rw,filter.hp_rw,filter.ham_rw);
end
stats.rw_mean = reshape(mean(stats.rw),25,3)';
stats.rw_mean1 = reshape(mean(stats.rw1),25,3)';


%%
% Bivariate Random Walk Model (GDP and UR)
true.y_rw_1 = [];
true.c_rw_1 = [];
filter.hp_rw_1 = [];
filter.ham_rw_1 = [];
stats.rw_1 = [];
A = [0.872066993	-0.246924848;...
-0.246924848	0.150246852];

for ii = 1: N 
    %generate data
     true.c_rw_1 =randn(T,2)*chol(A);
     true.y_rw_1 = cumsum(ones(T,1)*[0.77696 0.000704] + true.c_rw_1);
    
    %estimate cyclical component
    [~,filter.hp_rw_1] = hpfilter(true.y_rw_1,1600);
    [filter.ham_rw_1(:,1),~,~,~,~] = regfilter(true.y_rw_1(:,1),8,4);
    [filter.ham_rw_1(:,2),~,~,~,~] = regfilter(true.y_rw_1(:,2),8,4);

    %estimate statistics
    [stats.rw_1(ii,:),stats.rw1_1(ii,:) ] = fn_stats_bi(true.c_rw_1,filter.hp_rw_1,filter.ham_rw_1);
end
stats.rw_mean_1 = reshape(mean(stats.rw_1),25,3)';
stats.rw_mean1_1 = reshape(mean(stats.rw1_1),25,3)';




%%
%bi UC CQ
true.y_uc = [];
true.c_uc =[];
filter.hp_uc = [];
filter.ham_uc = [];
stats.uc = [];
stats.uc1 = [];

%Chan SInclair model
mu = [0.7895165 0.3744756];
phi1 = [1.5465581 1.0186242];
phi2 = [-0.6746452 -0.2108875];

A = [ 0.6346240	0.5906011	-0.6424216	-0.5486247; ...
0.5906011	3.0130351	-0.4007036	-3.5567972;...
-0.6424216	-0.4007036	1.0283951	0.2995332;...
-0.5486247	-3.5567972	0.2995332	4.4569530];

for ii = 1:N
    y = zeros(T,2);
    dy = zeros(T,2);

    tau = zeros(T,2);
    c = zeros(T,2);
    ETAEPS = randn(T,4)*chol(A);    
 
    for jj = 3:T
    tau(jj,:)= tau(jj-1,:) + mu + ETAEPS(jj,3:4);
    c(jj,:) = diag([phi2' phi1']*c(jj-2:jj-1,:))' + ETAEPS(jj,1:2);
    y(jj,:) = tau(jj,:) + c(jj,:);
    end
    true.c_uc = c;
    true.y_uc = y;
    
    %estimate cyclical component
    [~,filter.hp_uc] = hpfilter(true.y_uc,1600);
    [filter.ham_uc(:,1),~,~,~,~] = regfilter(true.y_uc(:,1),8,4);
    [filter.ham_uc(:,2),~,~,~,~] = regfilter(true.y_uc(:,2),8,4);

    %estimate statistics
    [stats.uc(ii,:),stats.uc1(ii,:)] = fn_stats_bi(true.c_uc,filter.hp_uc,filter.ham_uc);
end
stats.uc_mean = reshape(mean(stats.uc),25,3)';
stats.uc_mean1 = reshape(mean(stats.uc1),25,3)';

%%
%bi UC UR
true.y_uc_1 = [];
true.c_uc_1 =[];
filter.hp_uc_1 = [];
filter.ham_uc_1 = [];
stats.uc_1 = [];
stats.uc1_1 = [];

%Chan SInclair model
mu = [0.7776275 0.0008187];
phi1 = [0.6093671  0.7096745];
phi2 = [-0.1727197 -0.1459989];

A = [ 0.8981377	-0.5158104	-1.2064733	0.5905771;...
-0.5158104	0.4000961	0.7776815	-0.4506860;...
-1.2064733	0.7776815	2.0647533	-0.9417718;...
0.5905771	-0.4506860	-0.9417718	0.5547204];

for ii = 1:N
    y = zeros(T,2);
    dy = zeros(T,2);

    tau = zeros(T,2);
    c = zeros(T,2);
    ETAEPS = randn(T,4)*chol(A);    
 
    for jj = 3:T
    tau(jj,:)= tau(jj-1,:) + mu + ETAEPS(jj,3:4);
    c(jj,:) = diag([phi2' phi1']*c(jj-2:jj-1,:))' + ETAEPS(jj,1:2);
    y(jj,:) = tau(jj,:) + c(jj,:);
    end
    true.c_uc_1 = c;
    true.y_uc_1 = y;
    
    %estimate cyclical component
    [~,filter.hp_uc_1] = hpfilter(true.y_uc_1,1600);
    [filter.ham_uc_1(:,1),~,~,~,~] = regfilter(true.y_uc_1(:,1),8,4);
    [filter.ham_uc_1(:,2),~,~,~,~] = regfilter(true.y_uc_1(:,2),8,4);
    
    %estimate statistics
    [stats.uc_1(ii,:),stats.uc1_1(ii,:)] = fn_stats_bi(true.c_uc_1,filter.hp_uc_1,filter.ham_uc_1);
end
stats.uc_mean_1 = reshape(mean(stats.uc_1),25,3)';
stats.uc_mean1_1 = reshape(mean(stats.uc1_1),25,3)';



%% FIGURE 4
% (a)Biv. ramdom walk I
fn_plot_biUC4(stats.rw_mean1_1(:,9:17),'4rw_1',1)
% (b)Biv. eandom walk II
fn_plot_biUC4(stats.rw_mean1(:,9:17),'4rw',0)
% (c)Biv. unobserved components I
fn_plot_biUC4(stats.uc_mean1_1(:,9:17),'4uc_1',0)
% (d)Biv. unobserved components II
fn_plot_biUC4(stats.uc_mean1(:,9:17),'4uc',0)


%% Table 2 
table = [mean(stats.rw_mean_1(2,9:12),2) mean(stats.rw_mean_1(3,9:12),2)  stats.rw_mean_1(2,13) stats.rw_mean_1(3,13) mean(stats.rw_mean_1(2,14:17),2) mean(stats.rw_mean_1(3,14:17),2);...
            mean(stats.rw_mean_1(1,9:12),2) 1-mean(stats.rw_mean_1(3,9:12),2)  stats.rw_mean_1(1,13) 1-stats.rw_mean_1(3,13) mean(stats.rw_mean_1(1,14:17),2) 1-mean(stats.rw_mean_1(3,14:17),2);...
            mean(stats.rw_mean(2,9:12),2) mean(stats.rw_mean(3,9:12),2)  stats.rw_mean(2,13) stats.rw_mean(3,13) mean(stats.rw_mean(2,14:17),2) mean(stats.rw_mean(3,14:17),2);...
            mean(stats.rw_mean(1,9:12),2) 1-mean(stats.rw_mean(3,9:12),2)  stats.rw_mean(1,13) 1-stats.rw_mean(3,13) mean(stats.rw_mean(1,14:17),2) 1-mean(stats.rw_mean(3,14:17),2);...
            mean(stats.uc_mean_1(2,9:12),2) mean(stats.uc_mean_1(3,9:12),2)  stats.uc_mean_1(2,13) stats.uc_mean_1(3,13) mean(stats.uc_mean_1(2,14:17),2) mean(stats.uc_mean_1(3,14:17),2);...
            mean(stats.uc_mean_1(1,9:12),2) 1-mean(stats.uc_mean_1(3,9:12),2)  stats.uc_mean_1(1,13) 1-stats.uc_mean_1(3,13) mean(stats.uc_mean_1(1,14:17),2) 1-mean(stats.uc_mean_1(3,14:17),2);...
            mean(stats.uc_mean(2,9:12),2) mean(stats.uc_mean(3,9:12),2)  stats.uc_mean(2,13) stats.uc_mean(3,13) mean(stats.uc_mean(2,14:17),2) mean(stats.uc_mean(3,14:17),2);...
            mean(stats.uc_mean(1,9:12),2) 1-mean(stats.uc_mean(3,9:12),2)  stats.uc_mean(1,13) 1-stats.uc_mean(3,13) mean(stats.uc_mean(1,14:17),2) 1-mean(stats.uc_mean(3,14:17),2);];

Ham1 = [mean(stats.rw_mean_1(3,9:12),2)  mean(stats.rw_mean(3,9:12),2) mean(stats.uc_mean_1(3,9:12),2)  mean(stats.uc_mean(3,9:12),2)];
Ham2 = [stats.rw_mean_1(3,13) stats.rw_mean(3,13) stats.uc_mean_1(3,13) stats.uc_mean(3,13)];
Ham3 = [mean(stats.rw_mean_1(3,14:17),2) mean(stats.rw_mean(3,14:17),2) mean(stats.uc_mean_1(3,14:17),2) mean(stats.uc_mean(3,14:17),2)];

ave_score=[mean(Ham1) mean(Ham2) mean(Ham3); 1-mean(Ham1) 1-mean(Ham2) 1-mean(Ham3)];

Table7_paper = nan(10,6);
Table7_paper(1:8,:) = table;
Table7_paper(9:10,[2 4 6]) = ave_score;
