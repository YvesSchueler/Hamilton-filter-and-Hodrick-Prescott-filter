function [ output_normal,output_rt,output_dif,b,trend,stderr ] = regfilter(input,hval,pval)
%Regression filter adopted from Rats code of J. Hamilton
%by Yves S. Sch�ler 7/10/2017

% input = Tx1 vector of time series
% hval = scalar of forecast horizon
% pval = scalar of lagged values at time period t
% start and end are scalar to indicate the period for real time output
% series
start=1;
start2 = start + hval + pval;

[Y Ylag] = fn_lag(input,pval,0);
[Yh, ~] = fn_lag(input,pval+hval-1,0);

T = length(Yh);
output_rt = nan(size(input));

for ii = pval+1:T
[b, tstat, s2, vcv, vcvwhite, R2, Rbar, yhat,epsilon]=ols(Yh(1:ii),Ylag(1:ii,:),1);
output_rt(ii+hval+pval-1) = Yh(ii)-yhat(end);
end



[b, tstat, s2, vcv, vcvwhite, R2, Rbar, yhat,epsilon]=ols(Yh,Ylag(1:end-hval+1,:),1);
output_normal = [nan(hval+pval-1,1);Yh-yhat];
trend = [nan(hval+pval-1,1);yhat];

b = [b(2:end); b(1)];

tmp = sqrt(diag(vcvwhite));
stderr = [tmp(2:end,1); tmp(1,1)]; 


output_dif = [nan(hval,1); input(hval+1:end,1) - input(1:end-hval,1)];
end


