function [ out] = fn_stats(c_true,c_filter1,c_filter2)

idx1 = ~isnan(c_true.*c_filter1);
idx2 = ~isnan(c_true.*c_filter2);

c_t1 = c_true(idx1);
c_t2 = c_true(idx2);

c_f1 = c_filter1(idx1);
c_f2 = c_filter2(idx2);

rmse1 = sqrt(sum((c_t1 - c_f1).^2)/length(c_t1));
rmse2 = sqrt(sum((c_t2 - c_f2).^2)/length(c_t2));

rt_rmse1 = sqrt(sum((c_t1(end-11:end) - c_f1(end-11:end)).^2)/12);
rt_rmse2 = sqrt(sum((c_t2(end-11:end) - c_f2(end-11:end)).^2)/12);

cor1 = corr(c_t1,c_f1);
cor2 = corr(c_t2,c_f2);

[ar1_true, ~, ~, ~, ~, ~, ~, ~] = olsnw(c_t1(2:end),c_t1(1:end-1),1);
[ar1_1, ~, ~, ~, ~, ~, ~, ~] = olsnw(c_f1(2:end),c_f1(1:end-1),1);
[ar1_2, ~, ~, ~, ~, ~, ~, ~] = olsnw(c_f2(2:end),c_f2(1:end-1),1);

stdev_true = std(c_t1);
stdev1 = std(c_f1);
stdev2 = std(c_f2);

out1 = [(stdev_true-stdev_true)/stdev_true, (stdev1-stdev_true)/stdev_true, (stdev2-stdev_true)/stdev_true, ar1_true(2,1)-ar1_true(2,1) ,ar1_1(2,1)-ar1_true(2,1), ar1_2(2,1)-ar1_true(2,1)];
out2 = [rmse1 rmse2 rt_rmse1 rt_rmse2 cor1 cor2];
out = [out1 out2];


end

