function [vars ] = fn_transform_v4(Y_fin,Y_bus,T)


vars = struct;
vars.Q = nan(T,1);
vars.CQ = nan(T,1);

vars.Q = Y_bus;
vars.CQ= Y_fin;

%(log-)level
vars.lQ = log(vars.Q);


% hp filter with 1600
vars.hp1lQ = nan(T,1);
vars.hp1CQ = nan(T,1);
ii=1;
[~,vars.hp1lQ(~isnan(vars.lQ(:,ii)),ii)] = hpfilter(log(vars.Q(~isnan(vars.lQ(:,ii)),ii)),1600);
[~,vars.hp1CQ(~isnan(vars.CQ(:,ii)),ii)] = hpfilter((vars.CQ(~isnan(vars.CQ(:,ii)),ii)),1600);


%%% REAL TIME HP FILTERING
% hp filter with 1600
vars.hp1lQ_rt_adj = nan(T,1);
vars.hp1CQ_rt_adj = nan(T,1);

ii=1;
[vars.hp1lQ_rt_adj(~isnan(vars.lQ(:,ii)),ii), ~, ~ ] = adj1s_hpfilter(log(vars.Q(~isnan(vars.lQ(:,ii)),ii)),1600);
[vars.hp1CQ_rt_adj(~isnan(vars.CQ(:,ii)),ii), ~, ~ ] = adj1s_hpfilter((vars.CQ(~isnan(vars.CQ(:,ii)),ii)),1600);


% reg filter with 2years
vars.reg1lQ = nan(T,1);
vars.reg1CQ = nan(T,1);

ii=1;
[vars.reg1lQ(~isnan(vars.lQ(:,ii)),ii),~,~,vars.b.reg1lQ,~,~] = regfilter(log(vars.Q(~isnan(vars.lQ(:,ii)),ii)),8,4);
[vars.reg1CQ(~isnan(vars.CQ(:,ii)),ii),~,~,vars.b.reg1CQ,~,~] = regfilter((vars.CQ(~isnan(vars.CQ(:,ii)),ii)),8,4);

end

