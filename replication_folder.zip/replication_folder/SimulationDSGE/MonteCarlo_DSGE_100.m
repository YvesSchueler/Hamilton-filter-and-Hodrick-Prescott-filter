%Script to filter output gap.
clear all
close all


%UPDATE DATASET!

addpath('LRE')
addpath('Matfiles')
addpath('Mfiles')
addpath('Optimization Routines')
rng('default')


load Matfiles/mhdraws.mat % load posterior draws
[Theta, ~, ~]=moment(Thetasim(:,1:13));
Theta_wo = Theta;
Theta_wo(1,2) = 999999; %SET THIS TO INFTY FOR no PRICE RIGIDITIES... 

[T1, TC, T0, TETA, RC, retcode] = model_solution(Theta);
[A,B,H,R,Se,Phi] = sysmat(T1,T0,Theta);

[T1, TC, T0, TETA, RC, retcode] = model_solution(Theta_wo);
[A_wo,B_wo,H_wo,R_wo,Se_wo,Phi_wo] = sysmat(T1,T0,Theta_wo);


N = 5000;
T = 100;

%%
% Simulate Data from New Keynesian DSGE Model

%OUTPUT
true.y_dsge = [];
true.c_dsge = [];
true.c_dsge_wo = [];
true.ystar_dsge = [];
filter.hp_dsge_y = [];
filter.ham_dsge_y = [];
stats.dsge_y = [];

%PRICES
true.pi_dsge = [];
true.pi_c_dsge = [];
true.pistar_dsge = [];
filter.hp_dsge_pi = [];
filter.ham_dsge_pi = [];
stats.dsge_pi = [];

%INTEREST RATES
true.R_dsge = [];
true.R_c_dsge = [];
true.Rstar_dsge = [];
filter.hp_dsge_R = [];
filter.ham_dsge_R = [];
stats.dsge_R = [];

%correlation:
stats.corr_1 = [];
stats.corr_2 = [];



for ii = 1: N 

%=========================================================================
%                          TRANSITION EQUATION
%  
%           s(t) = Phi*s(t-1) + R*e(t)
%           e(t) ~ iid N(0,Se)
% y_t   = 1;
% pi_t   = 2;
% R_t   = 3;
% y1_t  = 4;
% g_t   = 5;
% z_t   = 6;
% Ey_t1   = 7;
% Epi_t1  = 8;
%=========================================================================
        eps_temp = randn(T,3);      
        
        s = zeros(T,8);
        eps = eps_temp*chol(Se);
        s(1,:) = eps(1,:)*R';

        s_wo = zeros(T,8);
        eps_wo = eps_temp*chol(Se_wo);
        s_wo(1,:) = eps_wo(1,:)*R_wo';

        %Log A_t etc
        lnA = zeros(T,1);
        lnA_wo = zeros(T,1);

    % Generate
    for t = 2:T
        s(t,:) = s(t-1,:)*Phi' + eps(t,:)*R';
        s_wo(t,:) = s_wo(t-1,:)*Phi_wo' + eps_wo(t,:)*R_wo';
 
        lnA(t,1) = log(1+Theta(1,7)) + lnA(t-1,1) + s(t,6); %Acummulate shock
        lnA_wo(t,1) = log(1+Theta_wo(1,7)) + lnA_wo(t-1,1) + s_wo(t,6);
    end

    %generate data
     %old
     true.c_dsge(:,ii) = s(:,1)-s(:,5); %y-g 
     true.y_dsge(:,ii) = s(:,1)+lnA; %y
     true.tau_dsge(:,ii) = s(:,5)+lnA; %g

     %new
     true.ystar_dsge(:,ii) = s_wo(:,1)+lnA_wo; %y
     true.c_dsge_wo(:,ii) = true.y_dsge(:,ii) - true.ystar_dsge(:,ii);


     %pi
     true.pi_dsge(:,ii) = s(:,2); 
     true.pistar_dsge(:,ii) = s_wo(:,2); 
     true.pi_c_dsge(:,ii) = true.pi_dsge(:,ii)-true.pistar_dsge(:,ii); 

     %R
     true.R_dsge(:,ii) = s(:,3); 
     true.Rstar_dsge(:,ii) = s_wo(:,3); 
     true.R_c_dsge(:,ii) = true.R_dsge(:,ii)-true.Rstar_dsge(:,ii); 
    
    %estimate cyclical component
    %output
    [~,filter.hp_dsge_y(:,ii)] = hpfilter(true.y_dsge(:,ii),1600);
    [filter.ham_dsge_y(:,ii),~,~,~,~] = regfilter(true.y_dsge(:,ii),8,4);
    %inflation
    [~,filter.hp_dsge_pi(:,ii)] = hpfilter(true.pi_dsge(:,ii),1600);
    [filter.ham_dsge_pi(:,ii),~,~,~,~] = regfilter(true.pi_dsge(:,ii),8,4);
    %interest rate
    [~,filter.hp_dsge_R(:,ii)] = hpfilter(true.R_dsge(:,ii),1600);
    [filter.ham_dsge_R(:,ii),~,~,~,~] = regfilter(true.R_dsge(:,ii),8,4);


    %estimate statistics    
    [stats.dsge_y(ii,:) ] = fn_stats(true.c_dsge(:,ii),filter.hp_dsge_y(:,ii),filter.ham_dsge_y(:,ii));
    [stats.dsge_pi(ii,:) ] = fn_stats(true.pi_c_dsge(:,ii),filter.hp_dsge_pi(:,ii),filter.ham_dsge_pi(:,ii));
    [stats.dsge_R(ii,:) ] = fn_stats(true.R_c_dsge(:,ii),filter.hp_dsge_R(:,ii),filter.ham_dsge_R(:,ii));

    [stats.corr_1(ii,:),stats.corr_2(ii,:) ] = fn_stats_bi([true.c_dsge(:,ii) true.pi_c_dsge(:,ii)],[filter.hp_dsge_y(:,ii) filter.hp_dsge_pi(:,ii)],[filter.ham_dsge_y(:,ii) filter.ham_dsge_pi(:,ii)]);
    [stats.corr_1R(ii,:),stats.corr_2R(ii,:) ] = fn_stats_bi([true.c_dsge(:,ii) true.R_c_dsge(:,ii)],[filter.hp_dsge_y(:,ii) filter.hp_dsge_R(:,ii)],[filter.ham_dsge_y(:,ii) filter.ham_dsge_R(:,ii)]);


end


std([true.pi_dsge(:,1) true.pistar_dsge(:,1) true.pi_c_dsge(:,1)])
std([true.y_dsge(:,1) true.tau_dsge(:,1) true.c_dsge(:,1)])
std([true.R_dsge(:,1) true.Rstar_dsge(:,1) true.R_c_dsge(:,1)])


corr([true.c_dsge(:,1) true.pi_c_dsge(:,1) true.R_c_dsge(:,1)])

stats.rw_mean_1 = reshape(mean(stats.corr_1),25,3)';
stats.rw_mean_1R = reshape(mean(stats.corr_1R),25,3)';

 [stats.rw_dsge_y] = fn_ind(stats.dsge_y);
 [stats.rw_dsge_pi] = fn_ind(stats.dsge_pi);
 [stats.rw_dsge_R] = fn_ind(stats.dsge_R);
 table_square = [stats.rw_dsge_y; stats.rw_dsge_pi; stats.rw_dsge_R];

table_square_ = [table_square(1,:); 1-table_square(1,:); table_square(2,:); 1-table_square(2,:); table_square(3,:); 1-table_square(3,:);];

  A = mean(stats.dsge_y);
  B = mean(stats.dsge_pi);
  C = mean(stats.dsge_R);
 
 idx = [3 2 6 5 12 11 8 7 10 9];

 table1_mean = [reshape(A(idx),2,5)']';

 table_pi = [mean(stats.rw_mean_1(2,9:12),2) mean(stats.rw_mean_1(3,9:12),2)  stats.rw_mean_1(2,13) stats.rw_mean_1(3,13) mean(stats.rw_mean_1(2,14:17),2) mean(stats.rw_mean_1(3,14:17),2);...
            mean(stats.rw_mean_1(1,9:12),2) 1-mean(stats.rw_mean_1(3,9:12),2)  stats.rw_mean_1(1,13) 1-stats.rw_mean_1(3,13) mean(stats.rw_mean_1(1,14:17),2) 1-mean(stats.rw_mean_1(3,14:17),2)];

 table_R = [mean(stats.rw_mean_1R(2,9:12),2) mean(stats.rw_mean_1R(3,9:12),2)  stats.rw_mean_1R(2,13) stats.rw_mean_1R(3,13) mean(stats.rw_mean_1R(2,14:17),2) mean(stats.rw_mean_1R(3,14:17),2);...
            mean(stats.rw_mean_1R(1,9:12),2) 1-mean(stats.rw_mean_1R(3,9:12),2)  stats.rw_mean_1R(1,13) 1-stats.rw_mean_1R(3,13) mean(stats.rw_mean_1R(1,14:17),2) 1-mean(stats.rw_mean_1R(3,14:17),2)];

table_piR = [table_pi; table_R];
mean(table_piR([1 3],:));
1-mean(table_piR([1 3],:));

 save DSGEall_100

  Table9_paper = [table1_mean(:,1) table_square_(:,1) table1_mean(:,2) table_square_(:,2) table1_mean(:,3) table_square_(:,3) table1_mean(:,4) table_square_(:,4)...
     table1_mean(:,5) table_square_(:,5)];