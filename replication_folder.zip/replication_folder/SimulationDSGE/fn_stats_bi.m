function [ out, out1] = fn_stats_bi(c_true,c_filter1,c_filter2)

idx1 = ~isnan(c_true.*c_filter1);
idx2 = ~isnan(c_true.*c_filter2);

c_t1 = c_true(idx1(:,1),:);
c_t2 = c_true(idx2(:,1),:);

c_f1 = c_filter1(idx1(:,1),:);
c_f2 = c_filter2(idx2(:,1),:);

%rmse1 = sqrt(sum((c_t1 - c_f1).^2)/length(c_t1));
%rmse2 = sqrt(sum((c_t2 - c_f2).^2)/length(c_t2));

%rt_rmse1 = sqrt(sum((c_t1(end-11:end) - c_f1(end-11:end)).^2)/12);
%rt_rmse2 = sqrt(sum((c_t2(end-11:end) - c_f2(end-11:end)).^2)/12);

crosscorr_t1 = crosscorr(c_t1(:,1),c_t1(:,2),12);
crosscorr_f1 = crosscorr(c_f1(:,1),c_f1(:,2),12);

crosscorr_t2 = crosscorr(c_t2(:,1),c_t2(:,2),12);
crosscorr_f2 = crosscorr(c_f2(:,1),c_f2(:,2),12);

temp1 = crosscorr_f1 - crosscorr_t1;
temp2 = crosscorr_f2 - crosscorr_t2;
temp3 = abs(temp2) <= abs(temp1);


out = [temp1' temp2' temp3'];
out1 = [crosscorr_t1' crosscorr_f1' crosscorr_f2'];


end

